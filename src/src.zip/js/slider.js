window.onload = function() {
    
    var d = document;

    var carousel = d.getElementById('carousel');
    var btnPrev = d.getElementById('left');
    var btnNext = d.getElementById('right');
    var review = d.querySelectorAll('.review');
    var btnContainer = d.querySelector('.slider-buttons');
    var slideW = 600;
    var left = 0;
    var reviewNum = review.length;
    var tick = 1;
    var buttons = [];

    btnNext.onclick = sliderRight;
    btnPrev.onclick = sliderLeft;

    for(i = 0; i < reviewNum; i++) {
        buttons[i] = document.createElement('button');
        btnContainer.appendChild(buttons[i]);
        buttons[i].classList.add('slider-button');
        buttons[i].addEventListener('click', function() {
            carousel.style.left = ((0 - (i * slideW)) + slideW) + 'px';
        });
    }

    function slideSwitch() {
        
    }

    function sliderRight() {
        if (tick < reviewNum) {
            tick++;
            left = left - slideW; // 51.2%
            carousel.style.left = left + 'px';
        } else {
            tick = 1;
            left = 0;
            carousel.style.left = left + '%';
        }
        
    }
    function sliderLeft() {
        if (tick > 1) {
            tick--;
            left = left + slideW;
            carousel.style.left = left +'px';
        } else {
            tick = reviewNum;
            left = 0 - ((slideW * reviewNum) - slideW);
            carousel.style.left = left + 'px';
        }
    }
}